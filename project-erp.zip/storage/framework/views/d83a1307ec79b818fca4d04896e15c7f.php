<svg class="h-5 w-5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/>
</svg><?php /**PATH C:\laragon\www\project-erp\storage\framework\views/d3dc7fd571030381e17b707e6c00a00f.blade.php ENDPATH**/ ?>